#' Predict
#'
#' @param trained_model It takes the pre-trained model as an input.
#' @param test_data It takes test data as an input to predict.
#'
#' @return
#' @export
#'
#' @examples predictions <- pred(trained_model, test_data)
pred <- function(trained_model, test_data){
  # Use the trained model to make predictions on test_data
  test_predictions <- predict(trained_model, test_data[, !(colnames(test_data) %in% c("orig_cls"))])

  return(test_predictions)
}
