#' Classify
#'
#' @param train_data It takes the train data.
#' @param test_data It takes the test data.
#' @param classification_method It takes classification method.
#' @param cross_validation_method It takes cross validation method.
#' @param number_of_folds It takes number of folds.
#' @param number_of_repeats It takes number of repeats.
#'
#' @return Returns the trained model
#' @export
#'
#' @examples trained_model <- classify(train_data, classification_method = "rf", cross_validation_method = "cv", number_of_folds = 2)
classify <- function(train_data, test_data, classification_method, cross_validation_method, number_of_folds, number_of_repeats = 0) {
  # Separate the features (x) and labels (y) in the training data
  x <- train_data[, !(colnames(train_data) %in% c("orig_cls"))]
  y <- train_data$orig_cls

  repeats <- 0
  if (cross_validation_method == "repeatedcv") {
    repeats <- number_of_repeats
  }

  ctrl <- trainControl(method = cross_validation_method, number = number_of_folds, repeats = repeats)

  # Train the model using the training data
  model <- train(x, y, method = classification_method, trControl = ctrl)

  # Return the trained model
  return(model)
}
