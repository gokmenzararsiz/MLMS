#' Split the data into training and testing sets
#'
#' @param mSet It takes mSet as an input.
#' @param train_test_split_ratio Determine the train/test split ratio. E.g. 0.7, 70% of the data will be used in train, 30% will be used in test.
#'
#' @return
#' @export
#'
#' @examples split_data_result <- split_data(data_transformed, train_test_split_ratio = 0.7) train_data <- split_data_result$train_data test_data <- split_data_result$test_data

split_data <- function(mSet, train_test_split_ratio) {
  # Convert data matrix to data frame with column names
  data_frame <- as.data.frame(mSet$dataSet$norm)
  colnames(data_frame) <- colnames(mSet$dataSet$norm)

  # Combine data frame with classes
  data <- cbind(data_frame, orig_cls = mSet$dataSet$orig.cls)


  n <- nrow(data)

  train_index <- sample(1:n, floor(train_test_split_ratio * n))
  train_data <- data[train_index, ]
  test_data <- data[-train_index, ]
  return(list(train_data = train_data, test_data = test_data))
}
