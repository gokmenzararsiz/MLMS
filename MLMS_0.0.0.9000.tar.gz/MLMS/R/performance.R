#' Performance of the predictions it prints confusion matrix
#'
#' @param predictions It takes predictions as an input.
#' @param reference_data It takes reference data.
#'
#' @return It returns confusion matrix.
#' @export
#'
#' @examples performance <- performance(predictions, test_data)
performance <- function(predictions, reference_data){
  confusion_matrix <- confusionMatrix(predictions, reference = reference_data$orig_cls)
  print("Confusion Matrix:")
  print(confusion_matrix)

}
