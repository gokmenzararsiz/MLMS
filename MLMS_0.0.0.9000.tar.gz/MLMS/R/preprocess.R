#' Preprocess the data
#'
#' @param data_path  It is a String variable that refers the address of the data file. If the data file is already in the working directory, the variable can be directly assigned to the name of the data file.
#' @param groups The set of the classes that the samples have. Ex: “A”, “B”, “B” ... etc.
#' @param data_type The type of data, either list (Compound lists), conc (Compound concentration data), specbin (Binned spectra data), pktable (Peak intensity table), nmrpeak (NMR peak lists), mspeak (MS peak lists), or msspec (MS spectra data)
#' @param anal_type  Indicate the analysis module to be performed: stat, pathora, pathqea, msetora, msetssp, msetqea, ts, cmpdmap, smpmap, or pathinteg
#' @param isDataPaired Indicate if the data is paired or not. Logical, default set to FALSE
#' @param data_label_type Specify the data label type, either categorical (disc) or continuous (cont)
#' @param removeMissingPercent Remove variables based upon a user-defined percentage cut off of missing values.If a user specifies a threshold of 20 in at least 20
#' @param replaceMissingMethod  Select the option to replace missing variables, either replacement based on the  minimum ("min),  the mean ("mean"),  the median ("median") value of each feature columns,  or several options to impute the missing values, using  k-nearest neighbour ("KNN"),  probabilistic PCA ("PPCA"),  Bayesian PCA ("BPCA") method, or  Singular Value Decomposition ("svdImpute")
#' @param filter   Select the filter option,  "rsd" which is the relative standard deviation, "nrsd" which is the non-parametric relative standard deviation,  "mean" which is the mean,  "sd" which is the standard deviation,  "mad" which is the median absolute deviation,  "iqr" which is the interquantile range.
#' @param isQCFilter  Filter the variables based on QC samples - True (T), or use non-QC based filtering - False (F).
#' @param rsd Define the relative standard deviation cut-off. Variables with a RSD greater than this number will be removed from the dataset. It is only necessary to specify this argument if isQCFilter is True (T). Otherwise, it will not be used in the function.
#' @param rowNorm Select the option for row-wise normalization,  "QuantileNorm" for Quantile Normalization,  "CompNorm" for  Normalization by a reference feature,  "SumNorm" for Normalization to constant sum,  "MedianNorm" for Normalizationto sample median,  "SpecNorm" for Normalization by a sample-specific factor.
#' @param transNorm Select option to transform the data,  "LogNorm" for Log Normalization,  "CrNorm" for Cubic Root Transformation
#' @param scaleNorm  Option for scaling the data,"MeanCenter" for Mean Centering,  "AutoNorm" for Autoscaling,  "ParetoNorm" for Pareto Scaling,  "RangeNorm" for Range Scaling.
#' @param ref Input the name of the reference sample or the reference feature, use " " around the name.
#' @param ratio This option is only for biomarker analysis.
#' @param ratioNum  Relevant only for biomarker analysis.
#' @param is_feature_selection  A Boolean value to indicate whether feature selection will applied or not. (T or F)
#' @param feature_selection_method Feature selection methods that can be: "rfe" (Recursive Feature Elimination), "ga" (Genetic Algorithm),  "elastic-net" (Elastic Net),  "svm" (Support Vector Machine),  "rf" (Random Forest),"t-test" (T-Tests).
#'
#' @return It returns mSet.
#' @export
#'
#' @examples data_transformed <-preprocess("XCMS-diffreport-MultiClass.xlsx", groups = sam_2, data_type= "pktable", anal_type= "stat", isDataPaired = FALSE, data_label_type = "disc", removeMissingPercent = 0.5, replaceMissingMethod = "KNN", filter = "mean", isQCFilter = FALSE, rsd = 0, rowNorm = "QuantileNorm", transNorm = "LogNorm", scaleNorm = "MeanCenter", ref = "Sample14", ratio = F, ratioNum = 20, is_feature_selection = T, feature_selection_method = "elastic-net") # can be rfe , ga, elastic-net, svm, rf, t-test
preprocess <- function(data_path, groups, data_type, anal_type, isDataPaired = F, data_label_type, removeMissingPercent, replaceMissingMethod, filter, isQCFilter, rsd, rowNorm, transNorm, scaleNorm, ref = NULL, ratio = NULL, ratioNum= NULL, is_feature_selection, feature_selection_method) {
  library(MetaboAnalystR)
  library(caret)
  library(xcms)
  library(readxl)
  gc()

  # This function converts processed raw LC/MS data from XCMS to a usable data object (mSet) for MetaboAnalyst.


  data_format = "rowu"
  data <- read_excel(data_path, sheet = 1)

  data <- data[, -1]  # Remove the first column
  data <- cbind(groups, data)  # Insert the new column at the beginning

  write.csv(data, file="PkTable.csv")
  mSet<-InitDataObjects(data_type, anal_type, isDataPaired)
  mSet<-Read.TextData(mSet, "PkTable.csv", data_format, data_label_type)
  print("mSet successfully created...")
  # print(mSet)


  # The sanity check function evaluates the accuracy of sample and class labels,
  # data structure, deals with non-numeric values, removes columns that are
  #constant across all samples (variance = 0), and by default replaces missing
  #values with half of the original minimal positive value in your dataset.
  mSet <- SanityCheckData(mSet)



  # Remove variables based upon a user-defined percentage cut-off of missing values.
  #If a user specifies a threshold of 20 in at least 20
  mSet <- RemoveMissingPercent(mSet, percent=removeMissingPercent)

  # Select the option to replace missing variables, either replacement based on
  #the minimum ("min), the mean ("mean"), or the median ("median") value of
  #each feature columns, or several options to impute the missing values,
  #using k-nearest neighbour ("KNN"), probabilistic PCA ("PPCA"),
  #Bayesian PCA ("BPCA") method, or Singular Value Decomposition ("svdImpute")
  mSet <- ImputeMissingVar(mSet, method= replaceMissingMethod)


  # This function will replace zero/missing values by half of the smallest
  #positive value in the original dataset. This method will be called after
  #all missing value imputations are conducted.
  # Check default value!!! By default, missing values will be replaced by 1/5 of min positive values of their corresponding variables

  mSet <- ReplaceMin(mSet)


  # The function applies a filtering method, ranks the variables within the
  # dataset, and removes variables based on its rank. The final dataset should
  #contain no more than than 5000 variables for effective computing.

  # filter: Select the filter option, "rsd" which is the relative standard deviation,
  #"nrsd" which is the non-parametric relative standard deviation, "mean" which is the mean,
  #"sd" which is the standard deviation, "mad" which is the median absolute deviation,
  #or "iqr" which is the interquantile range.

  # qcFilter: Filter the variables based on QC samples - True (T), or use non-QC based filtering - False (F).

  # rsd: Define the relative standard deviation cut-off. Variables with a RSD greater than this number will be removed from the
  #dataset. It is only necessary to specify this argument if qcFilter is True (T). Otherwise, it will not be used in the function.
  mSet <- FilterVariable(mSet, filter, isQCFilter, rsd)

  # Necessary before normalization
  mSet<-PreparePrenormData(mSet)


  #This function performs row-wise normalization, transformation, and scaling of your metabolomic data.
  # Check defaut methods!!!
  # rowNorm: Select the option for row-wise normalization, "QuantileNorm" for Quantile Normalization, "CompNorm" for
  # Normalization by a reference feature, "SumNorm" for Normalization to constant sum, "MedianNorm" for Normalization
  #to sample median, and "SpecNorm" for Normalization by a sample-specific factor.

  # transNorm: Select option to transform the data, "LogNorm" for Log Normalization, and "CrNorm" for Cubic Root Transformation

  # scaleNorm: Select option for scaling the data, "MeanCenter" for Mean Centering, "AutoNorm" for Autoscaling,
  #"ParetoNorm" for Pareto Scaling, amd "RangeNorm" for Range Scaling.

  # ref: Input the name of the reference sample or the reference feature, use " " around the name.
  # ratio : This option is only for biomarker analysis.
  # ratioNum: Relevant only for biomarker analysis.


  mSet<-Normalization(mSet, rowNorm, transNorm, scaleNorm, ref=ref, ratio=ratio, ratioNum=ratioNum)

  if(is_feature_selection){
    fs_methods_set = c("rfe","ga", "elastic-net", "svm", "rf", "t-test")
    if(feature_selection_method %in% fs_methods_set){

      if(feature_selection_method == "rfe"){

        # Apply feature selection method (e.g., Recursive Feature Elimination)
        ctrl <- rfeControl(functions = rfFuncs, method = "cv", number = 10)
        rfe_model <- rfe(mSet$dataSet$norm, mSet$dataSet$orig.cls, sizes = c(1:10), rfeControl = ctrl)

        # Retrieve selected features column names
        selected_features <- colnames(mSet$dataSet$norm[,rfe_model$optVariables])

        # Convert selected feature column names to character type
        indexes <- as.character(selected_features)


        if(length(indexes)>0){


          mSet$dataSet$norm <- mSet$dataSet$norm[c(indexes)]



          writeLines(c(paste0(length(indexes)," features are selected with Recursive Feature Elimination"),"Selected features :",indexes))

        }
        else{
          print("No important features are detected with Recursive Feature Elimination method!")
        }


      }

      else if(feature_selection_method == "ga"){

        ctrl <- gafsControl(functions = rfGA, method = "cv", number = 10)
        ga_model <- gafs(mSet$dataSet$norm, mSet$dataSet$orig.cls, gafsControl = ctrl)

        # Retrieve selected features column names
        selected_features <- colnames(mSet$dataSet$norm[,ga_model$optVariables])


        # Convert selected feature column names to character type
        indexes <- as.character(selected_features)

        if(length(indexes) != 0){


          mSet$dataSet$norm <- mSet$dataSet$norm[c(indexes)]

          writeLines(c(paste0(length(indexes)," features are selected with Genetic Algorithm"),"Selected features :",which(colnames(mSet$dataSet$norm[indexes]))))
        }
        else{
          print("No important features are detected with Genetic Algorithm method!")
        }


      }

      else if(feature_selection_method == "elastic-net"){

        library(glmnet)

        # Convert data frame to matrix
        data_matrix <- as.matrix(mSet$dataSet$norm)

        family_val = "binomial" #this is if there is two classes
        if (mSet$dataSet$cls.num >2){
          family_val = "multinomial"
        }

        # Create an elastic net model
        enet_model <- cv.glmnet(data_matrix, mSet$dataSet$orig.cls, family = family_val, alpha = 1)

        # Combine the 'dgCMatrix' objects into a single matrix
        all_beta_matrix <- do.call(cbind, enet_model$glmnet.fit$beta)

        # Find the indices of non-zero coefficients
        non_zero_indices <- which(all_beta_matrix != 0, arr.ind = TRUE)


        # Get the names of selected features
        selected_features <- colnames(data_matrix)[non_zero_indices[, 2]]

        indexes <- which(colnames(mSet$dataSet$norm) %in% selected_features)

        # Get the non-zero coefficient indices
        #non_zero_indices <- which(enet_model$glmnet.fit$beta[, 1] != 0)

        # Get the selected features based on non-zero coefficients
        #selected_features <- colnames(data_matrix)[non_zero_indices]

        if (length(selected_features) != 0){

          mSet$dataSet$norm <- mSet$dataSet$norm[c(indexes)]

          writeLines(c(paste0(length(indexes)," features are selected with Elastic-Net"),"Selected features :",unique(selected_features)))
        }
        else{
          print("No important features are detected with Elastic-Net method!")
        }

      }

      else if(feature_selection_method == "svm"){
        mSet<-RSVM.Anal(mSet, 10)
        output <- mSet$analSet$svm$sig.mat[which(mSet$analSet$svm$sig.mat[,"Freqency"] > 0),]

        # Get the index numbers as integers
        indexes <- as.character(names(output))


        if(length(indexes)>0){


          mSet$dataSet$norm <- mSet$dataSet$norm[c(indexes)]


          writeLines(c(paste0(length(indexes)," features are selected with Support Vector Machine"),"Selected features :",indexes))
        }
        else{
          print("No important features are detected with Support Vector Machine method!")
        }

      }

      else if(feature_selection_method == "rf"){
        mSet <- mSet<-RF.Anal(mSet, 500,7,1)

        #print(mSet$analSet$rf.sigmat)
        output <- mSet$analSet$rf.sigmat[which(mSet$analSet$rf.sigmat[,"MeanDecreaseAccuracy"] > 0),]

        # Get the index numbers as integers
        indexes <- as.character(names(output))

        if(length(indexes)>0){

          mSet$dataSet$norm <- mSet$dataSet$norm[c(indexes)]


          writeLines(c(paste0(length(indexes)," features are selected with Random Forest"),"Selected features :",indexes))
        }
        else{
          print("No important features are detected with Random Forest method!")
        }


      }

      else if(feature_selection_method == "t-test"){
        mSet<-Ttests.Anal(mSet, F, 0.05, FALSE, TRUE, "fdr", FALSE)
        if(mSet$analSet$tt$sig.num == 0){
          print("No important features are detected with T-Tests method")
        }
        else{

          mSet$dataSet$norm <- mSet$dataSet$norm[which(mSet$analSet$tt$sig.mat)]
          writeLines(c(paste0(length(indexes)," features are selected with T-Tests"),"Selected features :",which(mSet$analSet$tt$sig.mat)))

        }



      }

    }
  }



  # To save all files created during your session
  SaveTransformedData(mSet)
  print("Preprocessing Done!")

  return(mSet)


}
