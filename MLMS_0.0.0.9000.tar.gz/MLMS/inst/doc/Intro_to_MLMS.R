## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(MLMS)

## ----setup prob---------------------------------------------------------------
# Take a random sample from a uniform distribution
set.seed(112)

prob_2 <- c("0", "1","2")
sam_2 <- sample(prob_2, 204, replace = TRUE) # 204 is the total number of samples


