---
title: "Introduction to MLMS"
output: 
  pdf_document: 
    keep_tex: true
vignette: >
  %\VignetteIndexEntry{Introduction to MLMS}
  %\VignetteEngine{knitr::rmarkdown}
  %\VignetteEncoding{UTF-8}
---




```r
library(MLMS)
```


![plot of chunk sinus-plot](figure/sinus-plot-1.png)

```{=latex}
\documentclass{article}
\usepackage[T1]{fontenc}

\begin{document}

Here is a code chunk.

<<foo, fig.height=4>>=
1 + 1
par(mar = c(4, 4, .2, .2))
plot(rnorm(100))
@

You can also write inline expressions, e.g. $\pi=\Sexpr{pi}$,
and \Sexpr{1.9910214e28} is a big number.

\end{document}
```

This is introduction to MLMS package.
It is used to classify the mSet. 
Example case: 


```example

set.seed(112)
prob <- c("A", "B","C")  
sam <- sample(prob, 204, replace = TRUE) # 204 is the total number of samples


data_transformed <-perform_preprocess("XCMS-diffreport-MultiClass.xlsx",
                                              groups = sam,
                                              data_type= "pktable",
                                              anal_type= "stat",
                                              isDataPaired = FALSE,
                                              data_label_type = "disc",
                                              removeMissingPercent = 0.5,
                                              replaceMissingMethod = "KNN",
                                              filter = "mean",
                                              isQCFilter = FALSE,
                                              rsd = 0,
                                              rowNorm = "QuantileNorm",
                                              transNorm = "LogNorm",
                                              scaleNorm = "MeanCenter",
                                              ref = "Sample14",
                                              ratio = F,
                                              ratioNum = 20,
                                              is_feature_selection = T,
                                              feature_selection_method = "elastic-net" 
                                      )
```
